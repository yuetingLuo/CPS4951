package com.example.myoffer;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import com.example.myoffer.util.MainPage;
import com.example.myoffer.util.RegisterPage;

public class MainActivity extends AppCompatActivity {
    private Button blogin, bregister;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        blogin = (Button) findViewById(R.id.login);
        blogin.setOnClickListener((v -> {
            Intent intent = new Intent(MainActivity.this, MainPage.class);
            startActivity(intent);
        }));

        bregister = (Button) findViewById(R.id.register);
        bregister.setOnClickListener((v -> {
            Intent intent = new Intent(MainActivity.this, RegisterPage.class);
            startActivity(intent);
        }));
    }
}