package com.example.myoffer.util;

public class MainPage {
}
