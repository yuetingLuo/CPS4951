package com.xzp.forum.service;

import org.springframework.stereotype.Service;

@Service
public class RankService {

}
