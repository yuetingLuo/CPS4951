package com.xzp.forum.util;

public class EntityType {
	public static int ENTITY_COMMENT = 1;// ENTITY_TYPE=id_topic
	public static int ENTITY_USEFUL = 2;// ENTITY_TYPE=id_topic
}
